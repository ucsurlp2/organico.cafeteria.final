
package Interfaces;
import Modelo.Ventas;
import Modelo.Inventario;
import java.util.List;
public interface CRUD {
    public List listar();
    public List listarpr();
    public List listarprod();
    public List listarinv();
}
